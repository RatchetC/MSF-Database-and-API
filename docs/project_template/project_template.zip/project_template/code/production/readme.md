## Production
This is the top-level folder for production code (code you will use in your final product).
Give each code project its own folder under this one.  
Some projects (like ones which deploy to Heroku) are easier to handle if they have their own repo in git hub. If that's the case, create a folder for it here as usual, but just put a readme file in it. Put the new project in its own file structure, so that it doesn't get checked in as a part of this one. Add a URL to the new project in the readme you created for it. Any one coming to your project now knows where to go for all the dependent projects.


