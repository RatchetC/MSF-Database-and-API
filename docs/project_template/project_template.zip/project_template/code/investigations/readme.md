## Investigations
This is the top level directory for your investigations.
Each investigtion is a runnable project which demnstrates your thinking in a particular area; it may simply be a hello-world project, to demonstrate how to set up a local node server. 
If it's useful; check it in. 
Put each investigation in its own folder.
Note: Use github's ignore facility to exclude un-needed files from a project. If you're unsure what files to ignore, google the project type, or take a look [here](https://github.com/github/gitignore)
