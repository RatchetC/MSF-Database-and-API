## Proposal
This folder contains the proposal you will make to your client at the end of the requirements + design process.
The prooposal should describe the delivery: The minimum viable product and any bonus / sacrificial features, and the ammount of time over which the project will run
