## Worklogs

Give each member of your team a folder underneath this one.
A team member should provide a worklog for any investigative work which they are doing, so they can put important notes down, where they won't be forgotten.
That way, if they need help with something, there is always some reliable background infomation.

