## Budget
This folder contains the output of your commitment exercise:
Find out from your team the resources they will be bringing to the project. This will enable you to understand what you can achive from the brief.