## Investigations
This is the top level folder for your investigations.
You will use your investigations to evidence your decision-making as you design a product from its brief. 
Make sure you document your investigations appropriately: *don't* waste time and effort on formatting, *do* make sure you explain concepts and reasoning clearly.
Give each investigation its own folder under this one.
Link your documentation to code, in ../../code/investigations
