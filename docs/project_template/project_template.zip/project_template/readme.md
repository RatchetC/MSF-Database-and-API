## Template 
This is a template project structure.

Important files:

### effort_committment.xlsx

location: ./docs/budget/effort_committment.xlsx  

description: a spreadsheet file you can fill in. Add the hours you think your team will be able to give to the project. See the ammount of total effort you can bring to the project. Use this to help you estimate what can be achieved.



